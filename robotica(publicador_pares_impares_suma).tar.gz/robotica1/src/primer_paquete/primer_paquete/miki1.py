import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32  # Publicamos números enteros

class NodoImpares(Node):
    def __init__(self):
        super().__init__('nodo_impares')
        self.publisher = self.create_publisher(Int32, 'odd', 10)
        self.numero = 1  # Comienza en el primer impar
        self.timer = self.create_timer(1.0, self.timer_callback)

    def timer_callback(self):
        msg = Int32()
        msg.data = self.numero
        self.publisher.publish(msg)
        self.get_logger().info(f'📤 Publicando número impar: {msg.data}')
        self.numero += 2  # Avanza al siguiente impar

def main(args=None):
    rclpy.init(args=args)
    nodo = NodoImpares()
    rclpy.spin(nodo)
    nodo.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
