import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32  # Manejo de enteros

class NodoSumador(Node):
    def __init__(self):
        super().__init__('nodo_sumador')
        
        # Suscribirse a los tópicos /odd y /even
        self.subscription_odd = self.create_subscription(Int32, 'odd', self.callback_odd, 10)
        self.subscription_even = self.create_subscription(Int32, 'even', self.callback_even, 10)

        self.suma_cuadrados = 0  # Variable acumuladora

    def callback_odd(self, msg):
        self.sumar_cuadrado(msg.data)

    def callback_even(self, msg):
        self.sumar_cuadrado(msg.data)

    def sumar_cuadrado(self, numero):
        self.suma_cuadrados += numero ** 2  # Sumar el cuadrado del número recibido
        self.get_logger().info(f'➕ Suma de cuadrados hasta ahora: {self.suma_cuadrados}')

def main(args=None):
    rclpy.init(args=args)
    nodo = NodoSumador()
    rclpy.spin(nodo)
    nodo.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
