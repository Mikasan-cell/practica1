import rclpy
from rclpy.node import Node
from std_msgs.msg import Int8, Int32  # Recibe Int8, pero publica Int32

class NodoIntermedio(Node):
    def __init__(self):
        super().__init__('nodo_intermedio')  
        
        # Suscripción al tópico 'numbers' con tipo Int8
        self.subscription = self.create_subscription(
            Int8, 'numbers', self.listener_callback, 10)

        # Publicación en el tópico 'sum' con tipo Int32
        self.publisher = self.create_publisher(Int32, 'sum', 10)

        self.total_sum = 0  # Variable para almacenar la suma acumulada

    def listener_callback(self, msg):
        self.total_sum += msg.data  # Convertimos el valor de Int8 a Int32 (internamente en Python es automático)
        nuevo_msg = Int32()
        nuevo_msg.data = self.total_sum  # Publicamos la suma con Int32
        self.publisher.publish(nuevo_msg)
        self.get_logger().info(f'🔢 Suma acumulada hasta ahora: {self.total_sum}')

def main(args=None):
    rclpy.init(args=args)
    nodo_intermedio = NodoIntermedio()
    rclpy.spin(nodo_intermedio)
    nodo_intermedio.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
