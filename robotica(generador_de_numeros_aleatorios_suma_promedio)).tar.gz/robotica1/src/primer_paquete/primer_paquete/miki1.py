import rclpy
from rclpy.node import Node
from std_msgs.msg import Int8  # Mantiene Int8 como lo pide el ejercicio
import random

class NodoPublicador(Node):
    def __init__(self):
        super().__init__('nodo_publicador')
        self.publisher = self.create_publisher(Int8, 'numbers', 10)  # Publica en 'numbers' usando Int8
        time_period = 1.0  # 1 segundo de intervalo
        self.timer = self.create_timer(time_period, self.timer_callback)

    def timer_callback(self):
        msg = Int8()
        msg.data = random.randint(-128, 127)  # Se mantiene dentro del rango de Int8
        self.publisher.publish(msg)
        self.get_logger().info(f'📤 Publicando número aleatorio: {msg.data}')

def main(args=None):
    rclpy.init(args=args)
    nodo = NodoPublicador()
    rclpy.spin(nodo)
    nodo.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
