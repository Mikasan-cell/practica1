import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32  # Ahora solo usa Int32 para manejar grandes números

class NodoSuscriptor(Node):
    def __init__(self):
        super().__init__('nodo_suscriptor')
        
        # Suscripción al tópico 'sum' con tipo Int32
        self.subscription = self.create_subscription(
            Int32, 'sum', self.listener_callback, 10)

        self.total_sum = 0  # Acumulador de suma total
        self.count = 0  # Contador de mensajes recibidos

    def listener_callback(self, msg):
        self.count += 1
        self.total_sum += msg.data
        promedio = self.total_sum / self.count  # Cálculo del promedio en tiempo real
        self.get_logger().info(f'📊 Promedio en tiempo real: {promedio:.2f}')

def main(args=None):
    rclpy.init(args=args)
    nodo_suscriptor = NodoSuscriptor()
    rclpy.spin(nodo_suscriptor)
    nodo_suscriptor.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
